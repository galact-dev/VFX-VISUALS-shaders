# VFX Shaders — Site oficial
Site completo da VFX Shaders, preparado para GitHub Pages.

Conteúdo: página inicial, identidade VFX, recursos, galeria, versões, download do VFX Visuals 1.9 e instalação.

## Publicar
1. Crie um repositório público.
2. Envie o conteúdo desta pasta para a raiz.
3. Vá em Settings > Pages.
4. Selecione GitHub Actions.

O arquivo `.github/workflows/pages.yml` já está incluído para publicar automaticamente.

## Atualizar versões
Coloque novos `.mcpack` em `assets/downloads/` e atualize o card de versão no `index.html`.
